#include "CLMessageDeserializer.h"

CLMessageDeserializer::CLMessageDeserializer()
{
}

CLMessageDeserializer::~CLMessageDeserializer()
{
}