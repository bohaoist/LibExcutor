/*
 * CLMessage.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: haobo
 */
#include"CLMessage.h"

CLMessage::CLMessage(unsigned long lMsgID):m_clMsgID(m_lMsgID)
{
	m_lMsgID=lMsgID;
}
CLMessage::~CLMessage(){}
