#include "CLDataReceiver.h"

CLDataReceiver::CLDataReceiver()
{
}

CLDataReceiver::~CLDataReceiver()
{
}