/*
 * CLMessageSerializer.cpp
 *
 *  Created on: Jan 21, 2016
 *      Author: haobo
 */

#include"CLMessageSerializer.h"

CLMessageSerializer::CLMessageSerializer()
{

}
CLMessageSerializer::~CLMessageSerializer()
{

}



