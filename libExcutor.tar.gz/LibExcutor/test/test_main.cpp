/*
 * test_main.cpp
 *
 *  Created on: Nov 15, 2015
 *      Author: haobo
 */
//#include<gtest/gtest.h>

/*int main(int argc, char* argv[])
{
    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}*/



