/*
 * CLMessageObserver.cpp
 *
 *  Created on: Dec 23, 2015
 *      Author: haobo
 */

#include"CLMessageObserver.h"

CLMessageObserver::CLMessageObserver()
{

}
CLMessageObserver::~CLMessageObserver()
{

}
