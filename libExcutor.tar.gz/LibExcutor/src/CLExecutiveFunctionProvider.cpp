/*
 * CLExcutiveFunctionProvider.cpp
 *
 *  Created on: Dec 13, 2015
 *      Author: haobo
 */
#include <CLExecutiveFunctionProvider.h>

CLExecutiveFunctionProvider::CLExecutiveFunctionProvider()
{
}

CLExecutiveFunctionProvider::~CLExecutiveFunctionProvider()
{
}




