/*
 * CLMutexInterface.cpp
 *
 *  Created on: Jan 15, 2016
 *      Author: haobo
 */

#include"CLMutexInterface.h"

CLMutexInterface::CLMutexInterface()
{

}

CLMutexInterface::~CLMutexInterface()
{

}

