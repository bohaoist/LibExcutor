/*
 * CLExecutiveCommunication.cpp
 *
 *  Created on: Dec 23, 2015
 *      Author: haobo
 */
#include"CLExecutiveCommunication.h"


CLExecutiveCommunication::CLExecutiveCommunication()
{

}

CLExecutiveCommunication::~CLExecutiveCommunication()
{

}


