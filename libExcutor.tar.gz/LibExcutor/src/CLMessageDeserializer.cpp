/*
 * CLMessageDeserializer.cpp
 *
 *  Created on: Feb 22, 2016
 *      Author: haobo
 */

#include "CLMessageDeserializer.h"

CLMessageDeserializer::CLMessageDeserializer()
{
}

CLMessageDeserializer::~CLMessageDeserializer()
{
}


