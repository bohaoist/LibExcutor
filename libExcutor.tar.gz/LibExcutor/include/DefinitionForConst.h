#ifndef DefinitionForConst_H
#define DefinitionForConst_H

#define LOG_FILE_NAME "CLLogger.txt"
#define FILE_PATH_FOR_RECORD_LOCKING "/tmp/"

const int MUTEX_USE_RECORD_LOCK = 0;
const int MUTEX_USE_RECORD_LOCK_AND_PTHREAD = 1;
const int MUTEX_USE_SHARED_PTHREAD = 2;

const int ID_FOR_KEY = 32;
#define FILE_PATH_FOR_SHARED_MEMORY "/tmp/"

#define SHARED_SPACE_FOR_SHARED_MUTEX_ALLOCATOR "shared_space_for_shared_mutex_allocator"
#define SHARED_SPACE_FOR_SHARED_CONDITION_VARIABLE_ALLOCATOR "shared_space_for_shared_condition_variable_allocator"
#define SHARED_SPACE_FOR_SHARED_EVENT_ALLOCATOR "shared_space_for_shared_event_allocator"

#define MUTEX_FOR_SHARED_CONDITION_VARIABLE_ALLOCATOR "mutex_for_shared_condition_variable_allocator"
#define MUTEX_FOR_SHARED_MUTEX_ALLOCATOR "mutex_for_shared_mutex_allocator"
#define MUTEX_FOR_SHARED_EVENT_ALLOCATOR "mutex_for_shared_event_allocator"

const int LENGTH_OF_SHARED_OBJECT_NAME = 256;

const int UNINITIALIZED_SHARED_OBJECT = 0;
const int INITIALIZED_SHARED_OBJECT = 1;
const int ALLOCATED_SHARED_OBJECT = 2;

const int NUMBER_OF_SHARED_OBJECT = 1024;
const int MAGIC_NUMBER_FOR_SHARED_OBJECT = 0x12345678;

const int IOVECTOR_DELETE = 0;
const int IOVECTOR_STAIN = 1;
const int IOVECTOR_NON_DELETE = 2;

const long EXECUTIVE_IN_PROCESS_USE_STL_QUEUE = 0;
const long EXECUTIVE_IN_PROCESS_USE_PIPE_QUEUE = 1;
const long EXECUTIVE_BETWEEN_PROCESS_USE_PIPE_QUEUE = 2;

#define FILE_PATH_FOR_COMMUNICATION_NAMED_PIPE "/tmp/"
#define FILE_PATH_FOR_NAMED_PIPE "/tmp/"
#endif
