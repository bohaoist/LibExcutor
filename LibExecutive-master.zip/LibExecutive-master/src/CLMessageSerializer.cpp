#include "CLMessageSerializer.h"

CLMessageSerializer::CLMessageSerializer()
{
}

CLMessageSerializer::~CLMessageSerializer()
{
}