#include<fcntl.h>
#include<iostream>
#include<string.h>
#include<unistd.h>
#include<errno.h>
using namespace std;
int main()
{
    char buf[]= "i am writed.\n";
    cout << "i'm in new program." <<endl;
    int fd = open("./w.txt",O_WRONLY|O_CREAT|O_APPEND,S_IRUSR|S_IWUSR);
    if(fd == -1)
	{
		cout << "open error" << endl;
		cout << strerror(errno) <<endl;
	}
        
    write(fd,buf,strlen(buf));
    close(fd);
    return 0;
}
